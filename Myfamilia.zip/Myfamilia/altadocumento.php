<?php 
session_start();
if(@!$_SESSION['correo'])
{
  header("location:index.php");
}
$nombre_usuario = $_SESSION['nombre'];
$id_usuario = $_SESSION['id_usuario'];
$correo=$_SESSION['correo'];

date_default_timezone_set('America/Mexico_City');
$fecha_subida=date('Y-m-d');
?>
<?php
require("conexion.php");   
      // creamos las variables para subir a la db
        $ruta = "documentos/"; 
        $documento= trim ($_FILES['documento']['name']); //Eliminamos los espacios en blanco
        $documento= ereg_replace (" ", "", $documento);//Sustituye una expresión regular
        $subir= $ruta . $documento;  



        if(move_uploaded_file($_FILES['documento']['tmp_name'], $subir)) { //movemos el archivo a su ubicacion 
                   $nombre_doc  = $_POST['nombre_doc'];
                   $categoria_doc  = $_POST['categoria_doc'];
                   $descripcion_doc  = $_POST['descripcion_doc'];



                   $insertar = $mysqli->query("INSERT INTO documentos VALUES ('', '$nombre_doc', '$categoria_doc', '$descripcion_doc', '".$documento."', '$fecha_subida', '$id_usuario')");  
        }
        echo '<script>alert("Tu documento a sido dado de alta!")</script>';
        echo "<script>location.href='perfilus.php'</script>";
?> 