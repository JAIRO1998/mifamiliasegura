<?php 
$mysqli=new mysqli ("localhost","id11668043_jairosantiago","cibernet","id11668043_familia");
	if($mysqli->connect_errno){
		echo "fallo al conectar: (".$mysqli->connect_errno.")".$mysqli
		->connect_error;

	}
?>