<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
  <link type="text/css" rel="stylesheet" href="css/estilos.css"/>
  <link rel="stylesheet" href="css/all.css">
  <title>MI-FAMILIA.COM</title>
  <style type="text/css">
            body { 
                font: normal 10pt Helvetica, Arial;
                  }
  </style>
</head>
<body>
  <!-- navbar -->
  <div class="navbar-fixed-custom">
    <nav>
      <div class="nav-wrapper px-6">
        <a href="index.php">
          <img class="responsive-img" src="imagenes/logo.png" width="200" height="800">
        </a>
        <ul id="nav-mobile" class="right hide-on-med-and-down">
          <li>
            <a href="#home">Home</a>
          </li>
          <li>
            <a href="#sec-1">Únete</a>
          </li>
          <li>
            <a href="#modalLogin" class="modal-trigger">
              <i class="fas fa-user"></i>
            </a>
          </li>
        </ul>
      </div>
    </nav>
  </div>
  <!-- carousel -->
  <div id="home" class="carousel scrollspy carousel-slider carousel-custom">
    <a class="carousel-item" href="#one!">
      <img src="imagenes/1.jpg" height="500" width="200">
    </a>
    <a class="carousel-item" href="#two!">
      <img src="imagenes/2.jpg" height="500" width="200">
    </a>
    <a class="carousel-item" href="#three!">
      <img src="imagenes/3.jpg" height="500" width="200">
    </a>
    <a class="carousel-item" href="#four!">
      <img src="imagenes/5.jpg" height="500" width="200">
    </a>
  </div>
  <!-- seccion1 -->
   <div id="sec-1" class="section-custom scrollspy">
    <div class="row">
      <div class="col s12 text-center">
        <h2 class="center-align titulo-section">Únete</h2>
      </div>
    </div>
    <div class="row mt-2">
      <div class="col s6 px-4" align="end">
        <img class="responsive-img" src="imagenes/2.jpg" height="200px">
      </div>
      <div class="col s6 px-4">
        <h4><i class="fas fa-heart"></i> UNE A TU FAMILIA</h4>
        <p>UNETE TU Y TU FAMILIA Y DISFRUTA DE UNA MEJOR ADMINISTRACION DE LOS DOCUMENTOS PERSONALES DE CADA UNO DE LOS MIEMBROS</p>
        <a href="#modalRegistro" class="btn-custom modal-trigger">Unir a mi famila <i class="fas fa-heart"></i></a>
      </div>
    </div>
  </div>
  <!-- footer -->
  <footer class="page-footer footer-custom">
    <div class="container">
      <div class="row">
        <div class="col l6 s12">
          <h5 class="white-text">MI-FAMILIA.COM</h5>
          <p class="grey-text text-lighten-4">SIGUENOS EN NUESTRAS REDES SOCIALES Y ENTERATE DE TODO LO QUE HACEMOS</p>
        </div>
        <div class="col l4 offset-l2 s12">
          <h5 class="white-text">Redes sociales</h5>
          <ul>
            <li><a class="grey-text text-lighten-3" href="https://es-la.facebook.com/">Facebook</a></li>
            <li><a class="grey-text text-lighten-3" href="#!">Twitter</a></li>
            <li><a class="grey-text text-lighten-3" href="#!">Instagram</a></li>
          </ul>
        </div>
      </div>
    </div>
    <div class="footer-copyright footer-copyright-custom">
      <div class="container">
      © 2014 Copyright MI-FAMILIA.COM
      </div>
    </div>
  </footer>
  <a class="btn-to-top" href="#home"><i class="fas fa-chevron-up fa-2x"></i></a>

  <!-- MODALES -->
  <!-- Modal registro como donador -->
  <div id="modalRegistro" class="modal">
    <div class="modal-content px-3">
      <form name="formus" action="altaus.php" method="POST" autocomplete="off" enctype="multipart/form-data">
        <div class="row my-0">
          <div class="col s12">
            <h5><i class="fas fa-heart"></i> Quiero unirme</h5>
          </div>
        </div>
        <div class="row my-0">
          <div class="input-field col s4">
            <label>Nombre(s): </label>
            <input type="text" name="nombre" required><p>
          </div>
          <div class="input-field col s4">
            <label>Apellido Paterno:</label>
            <input type="text" name="apaterno" required><p>
          </div>
          <div class="input-field col s4">
            <label>Apellido Materno:</label>
            <input type="text" name="amaterno" required>
          </div>
        </div>
        <div class="row my-0">
          <div class="input-field col s3">
            <label>Telefono:</label>
            <input type="text" name="telefono" required><p>
          </div>
          <div class="input-field col s4">
            <label>Fecha de Nacimiento</label>
            <br>
            <br>
            <input type="date" name="fecha_nacimiento" required>
          </div> 
        </div>
        <div class="row my-0"> 
          <div class="input-field col s4">
            <label>Correo:</label>
            <input type="email" name="correo" required><p>  
          </div>  
          <div class="input-field col s4">
            <label>Password:</label>
            <input type="password" name="password" required><p>
          </div>
          <div class="input-field col s4">
            <label>Avatar:</label>
            <br>
            <br>
            <input type="file" name="foto" required><p>
          </div>
        </div>
        <div class="row my-0">
          <div class="col s12">
            <a class="modal-close btn-custom-danger">CANCELAR</a>
            <button type='submit' name="enviar" class="btn-custom mx-1">REGISTRARSE</button>
          </div>
        </div>
      </form>
    </div>
  </div>
  <!-- modal inicio sesion -->
  <div id="modalLogin" class="modal">
    <div class="modal-content px-1">
    <div class="row">
      <div id="test1" class="col s12">
        <center>
      <h5 class="indigo-text">Por favor, inicie sesión en su cuenta</h5>
      <div class="section"></div>

      <div class="container">
        <div class="z-depth-1 grey lighten-4 row" style="display: inline-block; padding: 32px 48px 0px 48px; border: 1px solid #EEE;">

          <form name="login" action="validacionlogin.php" method="POST">
            <div class='row'>
              <div class='col s12'>
              </div>
            </div>

            <div class='row'>
              <div class='col s12'>
                <label>Correo</label>
                <input type="email" name="correo"><p>
              </div>
            </div>

            <div class='row'>
              <div class='col s12'>
                <label>Contraseña</label>
                <input type="password" name="password"><p>
              </div>
            </div>
            <br />
            <center>
              <div class='row'>
                <button type='submit' name='btn_login' class='col s12 btn btn-large waves-effect indigo'>Iniciar Sesion</button>
              </div>
            </center>
          </form>
        </div>
      </div>
    </center>
      </div>
  </div>
    </div>
  </div>
  <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script> 
  <script type="text/javascript" src="js/materialize.min.js"></script>
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      //efecto de navbar
      $(window).scroll(function(){
        var scroll = $(window).scrollTop();
        if (scroll > 300) {
          $(".navbar-fixed-custom nav").css("background" , "#0c4152");
          $(".btn-to-top").css("bottom" , "40px");  	
        }
        else{
          $(".navbar-fixed-custom nav").css("background" , "rgba(0, 0, 0, 0.3)");
        }
      })
      // inicializar y autoplay carousel
      $('.carousel').carousel({
        indicators: true    
      });
      autoplay();
      
      function autoplay() {
        $('.carousel').carousel('next');
        setTimeout(autoplay, 4500);
      };
      //inicializar modal
      var elemsModal = document.querySelectorAll('.modal');
      var instancesModal = M.Modal.init(elemsModal);

      //inicializar parallax
      var elemsParallax = document.querySelectorAll('.parallax');
      var instancesParallax = M.Parallax.init(elemsParallax);

      //inicilizar scrollspy
      var elemsScrollspy = document.querySelectorAll('.scrollspy');
      var instancesScrollspy = M.ScrollSpy.init(elemsScrollspy,{scrollOffset:70});

      //inicializar tabs
      var elemsTabs = document.querySelectorAll('.tabs');
      var instanceTabs = M.Tabs.init(elemsTabs);
    });
  </script>
</body>
</html>