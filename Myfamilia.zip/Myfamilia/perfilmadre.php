<?php 
session_start();
if(@!$_SESSION['correo'])
{
  header("location:index.php");
}
$nombre_usuario = $_SESSION['nombre'];
$id_usuario = $_SESSION['id_usuario'];
$correo=$_SESSION['correo'];
$date=('Y-m-d');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
  <link type="text/css" rel="stylesheet" href="css/estilos.css"/>
  <link rel="stylesheet" href="css/all.css">
  <title>MI Perfil</title>
  <style type="text/css">
            body { 
                font: normal 10pt Helvetica, Arial; 
            }
        </style>
</head>
<script type="text/javascript">
  function ConfirmDelete()
  {
    var respuesta = confirm("Seguro de que deseas eliminar a este registro?")
    if (respuesta == true)
    {
      return true;
    }
    else
    {
      return false;
    }
  }
</script>
<body>
  <script type="text/javascript" src="js/materialize.min.js"></script>
  <script>
    document.addEventListener('DOMContentLoaded', function() {
        M.AutoInit();
        });
    </script>
  <!-- navbar -->
  <div class="navbar-fixed-custom">
    <nav>
      <div class="nav-wrapper px-6">
          <img class="responsive-img" src="imagenes/logo.png" width="200" height="800">
        <ul id="nav-mobile" class="right hide-on-med-and-down">
          <li>
            <a href="#home"><?php echo $nombre_usuario; ?></a>
          </li>
          <li>
            <a href="#sec-1">MIS DOCUMENTOS</a>
          </li>
          <li>
            <a href="#sec-2">MI FAMILIA</a>
          </li>
          <li>
            <a href="desconectar.php" class="modal-trigger">
              <i class="fas fa-sign-out-alt"></i>
            </a>
          </li>
        </ul>
      </div>
    </nav>
  </div>
  <!-- #home -->
  <div id="home" class="section-custom scrollspy">
    <div class="card">
        <div class="card-content">
<?php
    require("conexion.php");
    $consulta=$mysqli->query("SELECT * FROM usuarios where id_usuario='$id_usuario'");

    while($datos=$consulta->fetch_array())
{
?>
          <div class="row">
            <div class="col s3" align="end">
              <br>
              <br>
              <br>
              <img src="data:image/jpg;base64,<?php echo base64_encode($datos['foto']); ?>" height="200px">
            </div>
            <div class="col s9">
              <h4 align="center">HOLA <?php echo $nombre_usuario; ?></h4>
          <table class="egt">
    <tr>
      <th>NOMBRE</th>
      <th>APELLIDO PATERNO</th>
      <th>APELLIDO MATERNO</th>
    </tr>

    <tr>
      <td><?php echo $datos['nombre'] ?></td>
      <td><?php echo $datos['apaterno'] ?></td>
      <td><?php echo $datos['amaterno'] ?></td>
      <td></td>
    </tr>

    <tr>
      <th>TELEFONO</th>
      <th>FECHA DE NACIMIENTO</th>
      <th>CORREO</th>
    </tr>
    <tr>
      <td><?php echo $datos['telefono'] ?></td>
      <td><?php echo $datos['fecha_nacimiento'] ?></td>
      <td><?php echo $datos['correo'] ?></td>
    </tr>
<?php
}  
?>
</table>
         <div align="right">
            <a href="#modalupdate" class="btn-custom modal-trigger"><i class="material-icons right">autorenew</i>Modificar datos</a>
        </div>
            </div>
          </div>
        </div>
      </div>
  </div>
  <!-- #section1 -->
  <div id="sec-1" class="section-custom scrollspy">
    <div class="card">
        <div class="card-content">
          <div class="row">
            <div class="col s12">
              <h4 align="center">TUS DOCUMENTOS</h4>
              <div align="end">
                <a href="#modalRegistroDocumento" class="btn-custom modal-trigger"><i class="material-icons right">add</i>Agregar Documento</a>
              </div>
          <table class="egt">
    <tr>
      <th>NOMBRE</th>
      <th>CATEGORIA</th>
      <th>DESCRIPCION</th>
      <th>FECHA DE SUBIDA</th>
      <th>DOCUMENTO</th>
      <th>DESCARGAR</th>
    </tr>
<?php
    require("conexion.php");
    $consulta=$mysqli->query("SELECT * FROM documentos where id_usuario='$id_usuario'");

    while($datos=$consulta->fetch_array())
{
?>
    <tr>
      <td><?php echo $datos['nombre_doc'] ?></td>
      <td><?php echo $datos['categoria_doc'] ?></td>
      <td><?php echo $datos['descripcion_doc'] ?></td>
      <td><?php echo $datos['fecha_subida'] ?></td>
      <td><?php echo $datos['documento'] ?></td>
      <td></td>
    </tr>
<?php
}  
?>
</table>
            </div>
          </div>
        </div>
      </div>
  </div>
  <!-- seccion1 -->
   <div id="sec-2" class="section-custom scrollspy">
    <div class="row">
        <div class="col s12">
            <div class="card">
                <div class="card-content">
                  <h4 align="center">TU FAMILIA</h4>
                    <br>
                        <div class="row">
                            <?php
                              require("conexion.php");
                              $consulta=$mysqli->query("SELECT * FROM usuarios inner join niveles_acceso on usuarios.tipo_usuario=niveles_acceso.id_nivel where id_usuario!='$id_usuario'");
                              while($datos=$consulta->fetch_array())
                              {
                            ?>
                              <div class="col s3">
                              <div class="card z-depth-5">
                                <div class="card-image">
                                  <img src="data:image/jpg;base64,<?php echo base64_encode($datos['foto']); ?>" height="200px">
                                </div>
                                <div class="card-content">
                                  <h6>NOMBRE: <?php echo $datos['nombre']; ?></h6>
                                  <h6>PARENTESCO: <?php echo $datos['nivel']; ?></h6>
                                  <div align="end">
                                    <a href="#modalperfilfam?id=<?php echo $datos['id_usuario']; ?>" class="btn-custom modal-trigger"><i class="material-icons right">add</i>VER</a>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <?php 
                              }
                            ?>
                        </div>
                  </div>
                </div>
            </div>
        </div>
  </div>
  <!-- footer -->
  <footer class="page-footer footer-custom">
    <div class="container">
      <div class="row">
        <div class="col l6 s12">
          <h5 class="white-text">DONAN-TEC</h5>
          <p class="grey-text text-lighten-4">SIGUENOS EN NUESTRAS REDES SOCIALES Y ENTERATE DE TODO LO QUE HACEMOS</p>
        </div>
        <div class="col l4 offset-l2 s12">
          <h5 class="white-text">Redes sociales</h5>
          <ul>
            <li><a class="grey-text text-lighten-3" href="#!">Facebook</a></li>
            <li><a class="grey-text text-lighten-3" href="#!">Twitter</a></li>
            <li><a class="grey-text text-lighten-3" href="#!">Instagram</a></li>
          </ul>
        </div>
      </div>
    </div>
    <div class="footer-copyright footer-copyright-custom">
      <div class="container">
      © 2014 Copyright Donan-Tec
      </div>
    </div>
  </footer>

  <!-- MODALES -->
  <!-- modal actualizacion de datos -->
  <div id="modalupdate" class="modal">
    <div class="modal-content px-1">
    <div class="row">
      <div class="col s12">
        <form action="actualizaciondatosusuario.php" method="POST" enctype="multipart/form-data">
    <?php
   require("conexion.php");
   $consulta=$mysqli->query("SELECT * FROM usuarios where correo='$correo'");

   while($datos=$consulta->fetch_array())
     {
   ?>
    <div class="row">
    <div class="col s6">
      <label>Nombre: </label>
      <input type="text" name="nombre" value="<?php echo $datos['nombre'];?>">
    </div>
    <div class="col s6">
       <label>Apellido Paterno:</label>
       <input type="text" name="apaterno" value="<?php echo $datos['apaterno'];?>">
    </div>
  </div>
  <div class="row">
    <div class="col s6">
      <label>Apellido Materno:</label>
      <input type="text" name="amaterno" value="<?php echo $datos['amaterno'];?>">
    </div>
      <div class="col s6">
       <label>Fecha de nacimiento:</label>
      <input type="date" name="fecha_nacimiento" value="<?php echo $datos['fecha_nacimiento'];?>">
    </div>
  </div>
  <div class="row">
    <div class="col s6">
      <label>Telefono:</label>
      <input type="text" name="telefono" value="<?php echo $datos['telefono'];?>">
    </div>
    <div class="col s6">
      <label>Foto de perfil</label></p>
      <img src="data:image/jpg;base64,<?php echo base64_encode($datos['foto']); ?>" height="200px">
      <input type="file" name="foto">
    </div>
  </div>
<?php 
  }
?>
<a class="modal-close btn-custom-danger">CANCELAR</a>
<button  type='submit' name="actualizar" class="btn-custom mx-1">ACTUALIZAR</button>
</form>
      </div>
    </div>
    </div>
  </div>

    <!-- modal para agregar un documento -->
  <div id="modalRegistroDocumento" class="modal">
    <div class="modal-content px-1">
      <form name="formdoc" action="altadocumento.php" method="POST" autocomplete="off" enctype="multipart/form-data">
        <div class="row my-0">
          <div class="col s12">
            <h5><i class="fas fa-heart"></i> AGREGA UN NUEVO DOCUEMNTO</h5>
          </div>
        </div>
        <div class="row my-0">
              <div class="input-field col s4">
                  <label>Nombre del docuemto: </label>
                  <input type="text" name="nombre_doc" required><p>
              </div>
                <div class="input-field col s4">
                  <label>Categoria del documento</label></p>
                  <select name="categoria_doc">
                    <option value="MEDICO">Medico</option>
                    <option value="ESCOLAR">Escolar</option>
                    <option value="SOCIAL">Social</option>
                    <option value="OTRO">Otro</option>
                  </select>
                </div>
        </div>
          <div class="row my-0">
            <div class="input-field col s4">
              <label>Descripcion</label>
              <input type="text" name="descripcion_doc" required>
            </div>
            <div class="input-field col s4">
              <label>Selecciona tu documento PDF:</label>
              <br>
              <br>
              <input type="file" name="documento" required><p>
            </div>
          </div>
          <div class="row my-0">
          <div class="col s12">
            <a class="modal-close btn-custom-danger">CANCELAR</a>
            <button type='submit' name="enviar" class="btn-custom mx-1">SUBIR</button>
          </div>
        </div>
      </form>
    </div>
  </div>
<!-- modal de perfil familiar -->
  <div id="modalperfilfam" class="modal">
    <div class="modal-content px-1">
      <?php
      require("conexion.php");
      $id = $_REQUEST['id'];
      $consulta=$mysqli->query("SELECT * FROM usuarios inner join niveles_acceso on usuarios.tipo_usuario=niveles_acceso.id_nivel where id_usuario='$id'");
        $datos=$consulta->fetch_array();
      ?>
      <h6>NOMBRE: <?php echo $datos['nombre']; ?></h6>
    </div>
  </div>

  <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script> 
  <script type="text/javascript" src="js/materialize.min.js"></script>
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      //efecto de navbar
      $(window).scroll(function(){
        var scroll = $(window).scrollTop();
        if (scroll > 300) {
          $(".navbar-fixed-custom nav").css("background" , "#0c4152");    
        }
        else{
          $(".navbar-fixed-custom nav").css("background" , "rgba(0, 0, 0, 0.3)");
        }
      })
      // inicializar y autoplay carousel
      $('.carousel').carousel({
        indicators: true    
      });
      autoplay();
      
      function autoplay() {
        $('.carousel').carousel('next');
        setTimeout(autoplay, 4500);
      };
      //inicializar modal
      var elemsModal = document.querySelectorAll('.modal');
      var instancesModal = M.Modal.init(elemsModal);

      //inicializar parallax
      var elemsParallax = document.querySelectorAll('.parallax');
      var instancesParallax = M.Parallax.init(elemsParallax);

      //inicilizar scrollspy
      var elemsScrollspy = document.querySelectorAll('.scrollspy');
      var instancesScrollspy = M.ScrollSpy.init(elemsScrollspy,{scrollOffset:70});

      //inicializar tabs
      var elemsTabs = document.querySelectorAll('.tabs');
      var instanceTabs = M.Tabs.init(elemsTabs);
    });
  </script>
</body>
</html>