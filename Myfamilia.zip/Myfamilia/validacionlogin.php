<?php
session_start();
require("conexion.php");

$correo=$_POST['correo'];
$password=$_POST['password'];
$contador = 0;

$consultar=$mysqli->query("SELECT * FROM usuarios WHERE correo='$correo'");
while($dato=$consultar->fetch_array())
{
	if(password_verify($password, $dato['password']))
	{
		$_SESSION['correo']=$dato['correo'];
		$_SESSION['nombre']=$dato['nombre'];
		$_SESSION['id_usuario']=$dato['id_usuario'];
		if($dato['tipo_usuario']==1) 
		{
			echo '<script>alert("BIENVENIDO")</script>';
			echo "<script>location.href='perfilus.php'</script>";
		}
		elseif ($dato['tipo_usuario']==2) 
		{
			echo '<script>alert("BIENVENIDO")</script>';
			echo "<script>location.href='perfilmadre.php'</script>";
		}
		else
		{
			echo '<script>alert("BIENVENIDO")</script>';
			echo "<script>location.href='perfilhijo.php'</script>";
		}
	}
	else
	{
		echo '<script>alert("PASSWORD INCORRECTO")</script>';
		echo "<script>location.href='index.php'</script>";
	}
}
		echo '<script>alert("USUARIO INCORRECTO")</script>';
		echo "<script>location.href='index.php'</script>";
 ?>