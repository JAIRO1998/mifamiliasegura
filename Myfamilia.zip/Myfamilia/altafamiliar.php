<?php
require("conexion.php");

$nombre = $_POST['nombre'];
$apaterno = $_POST['apaterno'];
$amaterno = $_POST['amaterno'];
$telefono = $_POST['telefono'];
$fecha_nacimiento = $_POST['fecha_nacimiento'];
$correo = $_POST['correo'];
$password_normal = $_POST['password'];
$password=password_hash($password_normal, PASSWORD_DEFAULT);
$tipo_usuario = $_POST['tipo_usuario'];
$foto = addslashes(file_get_contents($_FILES['foto']['tmp_name']));

$insertar = $mysqli->query("INSERT INTO usuarios VALUES ('','$nombre', '$apaterno', '$amaterno', '$telefono', '$fecha_nacimiento', '$correo', '$password', '$tipo_usuario', '$foto')");

echo '<script>alert("Felicidades tu familiar a sido dado de alta!")</script>';
echo "<script>location.href='perfilus.php'</script>";
?>