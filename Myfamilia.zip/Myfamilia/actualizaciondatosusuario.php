<?php
session_start();
if(@!$_SESSION['correo'])
{
  header("location:login.html");
}
$correo=$_SESSION['correo'];
?>
<?php
require("conexion.php");

$nombre = $_POST['nombre'];
$apaterno = $_POST['apaterno'];
$amaterno = $_POST['amaterno'];
$telefono = $_POST['telefono'];
$fecha_nacimiento = $_POST['fecha_nacimiento'];
$foto = addslashes(file_get_contents($_FILES['foto']['tmp_name']));

$insertar = $mysqli->query("UPDATE usuarios SET
	nombre='$nombre',
	apaterno='$apaterno',
	amaterno='$amaterno',
	telefono='$telefono',
	fecha_nacimiento='$fecha_nacimiento',
	foto='$foto'
	where correo='$correo' 
	");

echo '<script>alert("Tus datos fueron actualizados con exito")</script>';
echo "<script>location.href='perfilus.php'</script>";
?>